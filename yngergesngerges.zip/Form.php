<!DocType HTML>
<html>

<head>
    
</head>

<body>


<script src="Check.js"></script>

<style> 
        .errorMessage{
            color: red;
        }
</style>

<?php 

$name = $email = $confirmEmail = $checkbox = $username = $pwd = $answer = $answer2 = $answer = $answer2 = $checkbox = $DropDown = $SecurityINFO = "";

$nameError = $emailError = $confirmEmailError = $checkboxError = $commentsError = $usernameError =$passwordError = $answerError = $answer2Error = $DropDownError = $SecurityINFOError = "";




    if($_SERVER["REQUEST_METHOD"] == "POST"){

        if(empty($_POST["name"])){ //if empty name input
            $nameError = "Name is Required*";
        }else{
            $name = input_data($_POST['name']);
            if(!preg_match("/^[a-zA-Z ]*$/", $name)){
                $nameError = "Only alphabets and white space are allowed";
            }
        }

        if(empty($_POST["email"])){ //if empty email
            $emailError = "Email is Required";
        } else {
            $email = input_data($_POST["email"]);
            //checks to see email is formated well
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
                $emailError = "Invalid Email";
            }
        }

        if(empty($_POST["confirmEmail"])){ //if empty email
            $confirmEmailError = "Re-Entering Email is Required";
        } else {
            $confirmEmail = input_data($_POST["confirmEmail"]);
            //checks to see email is formated well
            if (!filter_var($confirmEmail, FILTER_VALIDATE_EMAIL)){
                $confirmEmailError = "Invalid Email";
            }
        }

        if(empty($_POST["username"])){//if username is empty
            $usernameError = "Username is Required";
        }else{
            $username = input_data($_POST["username"]);
            if(!preg_match("/^[a-zA-Z ]*$/", $username)){
                $usernameError = "Only alphabets and white space are allowed";
            }
        }

        if(empty($_POST["pwd"])){//if username is empty
            $passwordError = "Password is Required";
        }else{
            $pwd = input_data($_POST["pwd"]);
            if(!preg_match("/^[a-zA-Z ]*$/", $pwd)){
                $passwordError = "Only alphabets and white space are allowed";
            }
        }

        if(empty($_POST["duration"])){ //if gender radio is unchecked
            $answerError = "This is Required";
        }else{
            $answer = input_data($_POST["duration"]);
        }

        if(empty($_POST["color"])){ //if gender radio is unchecked
            $answer2Error = "This is Required";
        }else{
            $answer2 = input_data($_POST["color"]);
        }

        if(empty($_POST["paper"]) ){
            $checkboxError = "This Field is Required";
        }else{
            $checkbox = input_data($_POST["paper"]);
        }

        if(empty($_POST["question"]) ){
            $DropDownError = "This Field is Required";
        }
        if(isset($_POST["question"])){
            $DropDown = input_data($_POST["question"]);
        }

        if(empty($_POST["SecurityINFO"])){
            $SecurityINFOError = "Answer to Security Question is Required";
        }else{
            $SecurityINFO = input_data($_POST["SecurityINFO"]);
        }

    }

    function input_data($Info){
        $Info = trim($Info); //removes Spaces from beginning and end
        $Info = stripslashes($Info);//removes quotes
        $Info = htmlspecialchars($Info); //removes special characters
        return $Info; 
    }
    
?>

<h1>Youstina N. Gerges</h1>
<!-- main content is form -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" >

     <!-- Text form-->
    <label for="name"><h3>Name: </h3></lable> 
    <input type="text" id="name" name="name" value="<?php echo $name; ?>"> 
    <span class="errorMessage">* 
        <?php echo $nameError; ?>
    </span>
    <br><br>

    <label for="email"><h3>Email: </h3></label>
    <input type="text" id="email" name="email" value="<?php echo $email; ?>">
    <span class="errorMessage">* 
        <?php echo $emailError; ?>
    </span>
    <br><br>

    <label for="confirmEmail"><h3>Confirm Email: </h3></label>
    <input type="text" id="confirmEmail" name="confirmEmail"  value="<?php echo $confirmEmail; ?>">
    <span class="errorMessage">* 
        <?php echo $confirmEmailError; ?>
    </span>
    <br><br>

    <!-- Check Similarity Button-->
    <input type="button" name="button" value="Check Similarity" onclick="checkSimilarity()">

    <!-- Text form-->
    <label for="username"><h3>Create Username: </h3> </label>
    <input type="text" id="username" name="username" value="<?php echo $username; ?>">
    <span class="errorMessage">* 
        <?php echo $usernameError; ?>
    </span>
    <br><br>

    <!-- Password form-->
    <label for="pwd"><h3>Create Password: </h3><label>
    <input type="password" id="pwd" name="pwd" value="<?php echo $pwd; ?>">
    <span class="errorMessage">* 
        <?php echo $passwordError; ?>
    </span>
    <br><br>

    <!-- Radio form 1-->
    <h3><label for="Time">Duration of Account: </label></h3>
    <input type="radio" id="Time" name="duration" value="1 year"  <?php if (isset($answer) && $answer == "1 year") echo "checked"; ?>>One Year
    <input type="radio"  name="duration" value="2 years" <?php if (isset($answer) && $answer == "2 years") echo "checked"; ?>>Two Years
    <input type="radio" name="duration" value="3 years" <?php if (isset($answer) && $answer == "3 years") echo "checked"; ?>>Three Years
    <span class="errorMessage">* 
        <?php echo $answerError; ?>
    </span>
    <br><br>

    <!-- Radio form 2-->
    <h3><label for="info">Favorite Primary Color: </label></h3> 
    <input type="radio" id="info" name="color" value="Red" <?php if (isset($answer2) && $answer2 == "Red") echo "checked"; ?>>Red
    <input type="radio" name="color" value="Blue" <?php if (isset($answer2) && $answer2 == "Blue") echo "checked"; ?>>Blue
    <input type="radio" name="color" value="Yellow" <?php if (isset($answer2) && $answer2 == "Yellow") echo "checked"; ?>>Yellow
    <span class="errorMessage">* 
        <?php echo $answer2Error; ?>
    </span>
    <br><br>

    <!-- checkbox form-->
    <label for="paper"><h3>What do you want to include?</h3></label>
    <input type="checkbox" id="paper1" name="paper" value="Resume" <?php if (isset($checkbox) && $checkbox == "Resume") echo "checked"; ?>>
    <label for="paper">Resume</label>
    <input type="checkbox" id="paper2" name="paper" value="CV" <?php if (isset($checkbox) && $checkbox == "CV") echo "checked"; ?>>
    <label for="paper">Cover Letter</label>
    <input type="checkbox" id="paper3" name="paper" value="Transcript" <?php if (isset($checkbox) && $checkbox == "Transcript") echo "checked"; ?>>
    <label for="paper">Transcript</label>
    <input type="checkbox" id="paper4" name="paper" value="Other document" <?php if (isset($checkbox) && $checkbox == "Other document") echo "checked"; ?>>
    <label for="paper">Other Document</label>
    <span class="errorMessage">* 
        <?php echo $checkboxError; ?>
    </span>
    <br><br>
    <br><br>

     <!-- Select form-->
    <label for="question">Choose Security Questions</label>
    <select id="question" name="question">
        <option value="">Select a Security Question</option>
        <option value="What is your Mom Maiden Name?" <?php if (isset($DropDown) && $DropDown == "What is your Mom Maiden Name?") echo "selected"; ?>>What is your Mom's Maiden Name?</option>
        <option value="What is your Best Friend Name?" <?php if (isset($DropDown) && $DropDown == "What is your Best Friend Name?") echo "selected"; ?>>What is your Best Friend's Name?</option>
        <option value="What is your First Pet Name?" <?php if (isset($DropDown) && $DropDown == "What is your First Pet Name?") echo "selected"; ?>>What is your First Pet's Name?</option>
        <option value="What is your Favorite Book Title?" <?php if (isset($DropDown) && $DropDown == "What is your Favorite Book Title?") echo "selected"; ?>>What is your Favorite Book title?</option>
        <option value="What is your Favorite Pet Peeve?" <?php if (isset($DropDown) && $DropDown == "What is your Favorite Pet Peeve?") echo "selected"; ?>>What is your Favorite pet peeve?</option>
    </select>
    <span class="errorMessage">* 
        <?php echo $DropDownError; ?>
    </span>
    <br><br>
    <br><br>

    <label for="answer">Answer the selected question</label>
    <textarea id="answer" name="SecurityINFO" rows="3" cols="40"><?php echo htmlspecialchars($SecurityINFO); ?></textarea>
    <span class="errorMessage">* 
        <?php echo $SecurityINFOError; ?>
    </span>
    <br><br>
    <br><br>

    <button onclick="validate()">Validate it!</button>

    <input type="submit" name="submit" value="Submit">
</form>

<?php
echo "<h2>Your Input:</h2>";
if(isset($_POST['submit'])){ //Only shows the outputs when submitted
if(empty($_POST["name"])){
echo "";
}else{
echo "<h4>Name: " . $name . "</h4>";
echo "<br>";
}

if(empty($_POST["email"])){
echo "";
}else{
echo "<h4> Email: " . $email . "</h4>";
echo "<br>";
}

if(empty($_POST["confirmEmail"])){
echo "";
}else{
echo "<h4> Confirmed Email: " . $confirmEmail . "</h4>";
echo "<br>";
}

if(empty($_POST["username"])){
echo "";
}else{
echo "<h4> Username: " . $username . "</h4>";
echo "<br>";
}

if(empty($_POST["pwd"])){
echo "";
}else{
echo "<h4> Password: " . $pwd . "</h4>";
echo "<br>";
}

if(empty($_POST["duration"])){
echo "";
}else{
echo "<h4> Activation Duration: " . $answer . "</h4>";
echo "<br>";
}

if(empty($_POST["color"])){
echo "";
}else{
echo "<h4> Preferred Color: " . $answer2 . "</h4>";
echo "<br>";
}

if(empty($_POST["paper"])){
echo "";
}else{
echo "<h4> Document: " . $checkbox . "</h4>";
echo "<br>";
}

if(empty($_POST["question"])){
echo "";
}else{
echo "<h4> Security Question: " . $DropDown . "</h4>";
echo "<br>";
}

if(empty($_POST["SecurityINFO"])){
echo "";
}else{
echo "<h4> Security Answer: " . $SecurityINFO . "</h4>";
echo "<br>";
}
}
?>
</body>

</html>