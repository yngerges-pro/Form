function checkSimilarity() {
    const email = document.getElementById("email").value;
    const confirmEmail = document.getElementById("confirmEmail").value;

    if(email === confirmEmail){
        alert("The inputs are the same");
    }else{
        alert("The inputs not are the same");
    }
}

function validate(){
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const confirmEmail = document.getElementById("confirmEmail").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("pwd").value;
    const SecurityQuestion = document.getElementById("question").value;
    const SecurityINFO = document.getElementById("answer").value;
    
    
    if ( name === "") {
        alert("Name is Required");
    }

    if ( email === "") {
        alert("Email is Required");
    }

    if ( confirmEmail === "") {
        alert("Re-Entering your email is Required");
    }

    if ( username === "") {
        alert("Username is Required");
    }

    if ( password === "") {
        alert("Password is Required");
    }

    radio();

    radio2();

    checkbox();

    if (SecurityQuestion === ""){
        alert("Security Question Selection is Required");
    }

    if (SecurityINFO === ""){
        alert("Security Answer is Required");
    }

    

}

function radio(){
    const radios = document.getElementsByName('duration');
    var checked = false;

    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            checked = true;
        }
    }

    if (!checked) {
        alert('Account Duration is Required');
    }
}

function radio2(){
    const radios = document.getElementsByName('color');
    var checked = false;

    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            checked = true;
        }
    }

    if (!checked) {
        alert('Primary Color is Required');
    }
}

function checkbox(){
    const papers = document.getElementsByName('paper');
    var checked = false;

    for (var i = 0; i < papers.length; i++) {
        if (papers[i].checked) {
            checked = true;
        }
    }

    if (!checked) {
        alert('Selection of Document(s) is Required');
    }
}